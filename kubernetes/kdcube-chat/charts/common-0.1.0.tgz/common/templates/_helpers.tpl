{{/*
Common Helm library for generating Kubernetes manifests from values.
This chart is intentionally minimal: it provides helpers for creating
Service, Deployment, Job, PVC, ServiceAccount, Secret, and ConfigMap.

The helpers are defensive: they tolerate missing values in the input
values.yaml and fall back to safe defaults.
*/}}

{{- define "common.name" -}}
{{- if .Values.name -}}
{{- .Values.name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "common.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- include "common.name" . -}}
{{- end -}}
{{- end -}}

{{- define "common.labels" -}}
{{- $values := .Values -}}
{{- $deployment := default dict $values.deployment -}}
{{- $service := default dict $values.service -}}
{{- $pod := default dict $values.pod -}}
{{- $labels := dict -}}
{{- $labels = merge $labels (default dict $values.labels) -}}
{{- $labels = merge $labels (default dict $deployment.labels) -}}
{{- $labels = merge $labels (default dict $service.labels) -}}
{{- $labels = merge $labels (default dict $pod.labels) -}}
{{- $labels = merge $labels (dict "app.kubernetes.io/name" (include "common.name" .)) -}}
{{- $labels = merge $labels (dict "app.kubernetes.io/instance" .Release.Name) -}}
{{- toYaml $labels | nindent 4 -}}
{{- end -}}

{{- define "common.annotations" -}}
{{- $values := .Values -}}
{{- $deployment := default dict $values.deployment -}}
{{- $service := default dict $values.service -}}
{{- $pod := default dict $values.pod -}}
{{- $annotations := dict -}}
{{- $annotations = merge $annotations (default dict $values.annotations) -}}
{{- $annotations = merge $annotations (default dict $deployment.annotations) -}}
{{- $annotations = merge $annotations (default dict $service.annotations) -}}
{{- $annotations = merge $annotations (default dict $pod.annotations) -}}
{{- toYaml $annotations | nindent 4 -}}
{{- end -}}

{{- define "common.envFrom" -}}
{{- $deployment := default dict .Values.deployment -}}
{{- $envFrom := default (default list .Values.envFrom) $deployment.envFrom -}}
{{- if $envFrom -}}
envFrom:
{{- range $envFrom }}
  - {{- if hasKey . "configMapRef" -}}
      configMapRef:
        name: {{ .configMapRef.name | quote }}
    {{- else if hasKey . "secretRef" -}}
      secretRef:
        name: {{ .secretRef.name | quote }}
    {{- else -}}
      # unsupported envFrom entry
    {{- end -}}
{{- end }}
{{- end -}}
{{- end -}}

{{- define "common.env" -}}
{{- $deployment := default dict .Values.deployment -}}
{{- $env := default (default dict .Values.env) $deployment.env -}}
{{- if $env -}}
env:
{{- range $key, $val := $env }}
  - name: {{ $key | quote }}
    value: {{ $val | quote }}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "common.envBlock" -}}
{{- $deployment := default dict .Values.deployment -}}
{{- $blocks := default (default list .Values.envBlock) $deployment.envBlock -}}
{{- if $blocks -}}
{{- range $idx, $block := $blocks }}
{{- if $block.name }}
  - name: {{ $block.name | quote }}
    {{- if $block.value }}
    value: {{ $block.value | quote }}
    {{- end }}
    {{- if $block.valueFrom }}
    valueFrom:
      {{- toYaml $block.valueFrom | nindent 6 }}
    {{- end }}
{{- end }}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "common.volumeMounts" -}}
{{- $mounts := default list .Values.volumeMounts -}}
{{- $volumes := default list .Values.volumes -}}
{{- if $mounts -}}
volumeMounts:
{{- range $mounts }}
  - name: {{ .name | quote }}
    mountPath: {{ .mountPath | quote }}
    {{- if .subPath }}
    subPath: {{ .subPath | quote }}
    {{- end }}
    {{- if .readOnly }}
    readOnly: {{ .readOnly }}
    {{- end }}
{{- end -}}
{{- else if $volumes -}}
volumeMounts:
{{- range $volumes }}
  {{- if .mountPath }}
  - name: {{ .name | quote }}
    mountPath: {{ .mountPath | quote }}
    {{- if .subPath }}
    subPath: {{ .subPath | quote }}
    {{- end }}
    {{- if .readOnly }}
    readOnly: {{ .readOnly }}
    {{- end }}
  {{- end }}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "common.volumes" -}}
{{- $volumes := default list .Values.volumes -}}
{{- if $volumes -}}
volumes:
{{- range $volumes }}
  - name: {{ .name | quote }}
    {{- if .hostPath }}
    hostPath:
      path: {{ .hostPath.path | quote }}
      {{- if .hostPath.type }}
      type: {{ .hostPath.type | quote }}
      {{- end }}
    {{- end }}
    {{- if .configMap }}
    configMap:
      name: {{ .configMap.name | quote }}
    {{- end }}
    {{- if .secret }}
    secret:
      secretName: {{ .secret.secretName | quote }}
    {{- end }}
    {{- if .persistentVolumeClaim }}
    persistentVolumeClaim:
      claimName: {{ .persistentVolumeClaim.claimName | quote }}
    {{- end }}
    {{- if .emptyDir }}
    emptyDir:
      {{- range $k, $v := .emptyDir }}
      {{ $k }}: {{ $v | quote }}
      {{- end }}
    {{- end }}
{{- end -}}
{{- end -}}
{{- end -}}

